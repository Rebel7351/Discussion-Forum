from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from forum.views import *
from forum import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', signin),
    path('signup/', signup),
    path('discussion/', post_question),
    path('logout/', signout),
    path('question/<int:qid>/', question_page),
    path('upvote/<int:aid>/', upvote),
    path('comment/<int:aid>/', comment),
    path('profile/',profile),
    path('index/', index),
    path('', signup),
     path('oauth/', include('social_django.urls', namespace='social')),
    
] +  staticfiles_urlpatterns()

LOGIN_URL = 'login'
LOGOUT_URL = 'logout'
LOGIN_REDIRECT_URL = '/'

